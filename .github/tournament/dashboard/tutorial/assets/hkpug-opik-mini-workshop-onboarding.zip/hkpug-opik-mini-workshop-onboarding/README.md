# HKPUG Opik Mini Workshop Onboarding

This public bundle contains the existing six mini-workshop traces, span trees,
feedback scores, Dataset and Experiments data, Python case files, questions, and
answer key. It does not contain any hidden 14-day tournament cases.

## Load into local Opik

1. Start Opik and wait for http://localhost:5173 to become available.
2. Install the latest `hkpug-opik-helper` release.
3. From this extracted directory, run:

```sh
hkpug-opik-helper load \
  --feedback opik \
  --opik-url http://localhost:5173/api \
  --workspace default
```

Open the `HKPUG Mini Workshop Onboarding` project, choose **Logs**, then **Traces**. Case 006
also uses the **Experiments** page.
